import { render, screen } from '@testing-library/react';
import Footer from './footer';
import React from 'react';

test('renders footer text', () => {
  render(<Footer />);
  const testText = screen.getByText(/This is the Footer./i);
  expect(testText).toBeInTheDocument();
});
