import { render, screen } from '@testing-library/react';
import {shallow} from 'enzyme';
import Cart from './Cart';
import React from 'react';


test('renders testing text', () => {
  const component = shallow(
  <Cart
    title='React is Awesome'
    author='Chris'
    CartItems = {jest.fn}
   
  />);
	expect(component.text()).toContain('React is Awesome');
});
