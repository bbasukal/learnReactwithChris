import React from 'react';
function ContactUs(){
    return(
        <h1>
            Contact Us
        </h1>
    )
}
export default ContactUs;