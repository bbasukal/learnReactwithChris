import React from 'react';

function Footer(props){
    return (
        <footer>
            <p>This is the Footer. You can close this page</p>
            <p>this is test</p>
            </footer>
          );
}
export default Footer;