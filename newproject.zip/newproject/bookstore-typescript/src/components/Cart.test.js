import { render, screen } from '@testing-library/react';
import Cart from './Cart';


test('renders learn react link', () => {
  render(<Cart />);
  const CartElement = screen.getByText(/Total/i);
  expect(CartElement).toBeInTheDocument();
});
