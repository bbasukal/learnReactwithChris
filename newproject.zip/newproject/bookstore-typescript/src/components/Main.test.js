import { render, screen } from '@testing-library/react';
import Main from './Main';

test('renders learn react link', () => {
  render(<Main />);
  const linkElement = screen.getByText(/main part/i);
  expect(linkElement).toBeInTheDocument();
});
