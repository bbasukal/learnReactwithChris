function Header(){
    return (
        <header>
            <p>Welcome to React Bookstore header</p>
            </header>
          );
}
export default Header;