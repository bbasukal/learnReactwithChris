import { render, screen } from '@testing-library/react';
import Product from './Product';

test('renders learn react link', () => {
  render(<Product />);
  const ProductElement = screen.getByText(/Add to Cart/i);
  expect(ProductElement).toBeInTheDocument();
});
