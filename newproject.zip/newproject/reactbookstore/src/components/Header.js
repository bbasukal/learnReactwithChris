import React from 'react';
import {Link} from 'react-router-dom';
function Header(){
    return (
        <header>
                <Link to='/Cart'> Go to Cart </Link>
                <p>Welcome to React Bookstore header</p>
            </header>
          );
}
export default Header;