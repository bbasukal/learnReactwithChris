import { render, screen } from '@testing-library/react';
import Header from './Header';
import React from 'react';

test('renders Bookstore header', () => {
  render(<Header />);
  const HeaderBElement = screen.getByText(/Bookstore header/i);
  expect(HeaderBElement).toBeInTheDocument();
});
